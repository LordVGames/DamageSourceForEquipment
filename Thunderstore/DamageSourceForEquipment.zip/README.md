# DamageSourceForEquipment

When the SOTS phase 2 update dropped, Gearbox added another damage source option: Equipment! This can let items/character abilities do things depending on damage from specifically equipments! However, Gearbox didn't actually implement the damage source for any equipment that deal damage, rendering it practically useless. This mod fixes that!

Hopefully, when the SOTS phase 3 update drops, Gearbox will have officially implemented the equipment damage source and this mod can be deprecated. Until then, use this mod if you plan to utilize the equipment damage source.