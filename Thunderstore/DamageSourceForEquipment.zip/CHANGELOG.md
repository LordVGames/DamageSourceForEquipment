## 2.0.1

- Updated for MonoDetour 0.7.6

## 2.0.0

- Fixed for AC release
- Made overloading orbs count as equipment damage
- "Aspect damage is equipment" config is true by default
- Ported to MonoDetour

## 1.0.2

- Fixed WolfoItemBuffs' pocket ICBM change breaking this mod's disposable missile launcher change

## 1.0.1

- Fixed ItemStatistics causing this mod's gilded spike hook to die

## 1.0.0

- First release